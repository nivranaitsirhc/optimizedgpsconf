# **Optimized GPS Conf**
## Description
Replaces the android default gps.conf which is miconfigured most of the time.

Fork from Original Module - https://github.com/JonasCardoso/optmizedgpsconf

## DISCLAMER
This module is provided as-is. Always use the stable version.

## Versioning
```
A.B.C - Version Code
AABBCC - Version Number

Major - A.0.0
Minor - A.B.0
Release Candidate - A.B.C
```
